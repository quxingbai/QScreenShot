﻿using QScreenShot;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        protected override void OnPreviewMouseDown(MouseButtonEventArgs e)
        {
            Hide();
            //ScreenUtils.Show((img) =>
            //{
            //    BitmapImage bmpImage = img.Image.Value;
            //    System.Drawing.Bitmap bmp = img.BitmapSource;
            //});

            Task.Run(() =>
                    {
                        Thread.Sleep(250);

                        Dispatcher.Invoke(() =>
                        {
                            ScreenUtils.Show((img) =>
                            {
                                this.Content = new Image()
                                {
                                    Source = img.Image.Value
                                };
                                Show();
                            }, null, (c) =>
                            {
                                Show();
                                return true;
                            });
                        });
                    });

            base.OnPreviewMouseDown(e);
        }
    }
}
